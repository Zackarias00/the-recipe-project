package org.LiftOff.TheRecipeProject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TheRecipeProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(TheRecipeProjectApplication.class, args);
	}

}
